#ifndef DISPLAY_H
#define DISPLAY_H

#include "game.h"

void display_map(GameState* game);
void clear_screen(void);
#endif